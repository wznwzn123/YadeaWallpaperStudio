# Yadea Wallpaper Studio — Android 诊断原型

目标设备：雅迪 G5Ⅱ Pro-M 悦享版双碟 EC-A，彩色仪表，固件信息由用户提供为 0.43。
官方 App：雅迪智行 8.8.12。
当前版本：0.1.0-diagnostic。

## 当前实现
- 从系统图片选择器选择图片并预览。
- 将所选图片保存到应用私有目录。
- 扫描附近 BLE 设备。
- 连接用户选中的 BLE 设备并枚举 GATT 服务、特征、描述符 UUID 和常见属性。
- 可复制诊断日志。

## 明确未实现
- 没有伪造雅迪协议、服务 UUID、图片格式、分包格式或认证流程。
- 不会向车辆/仪表写入任何 GATT 特征。
- 发现 WRITE 属性不代表该特征是壁纸上传通道。
- 当前保存壁纸仅保存在手机 App 私有目录，不会改变仪表显示。

## 构建
1. 使用 Android Studio 打开此目录。
2. 使用 JDK 17。
3. 等待 Gradle 同步，安装 Android SDK Platform 35。
4. 选择 Build > Build APK(s)。
5. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

项目使用 Android Gradle Plugin 8.7.3 / Kotlin 2.0.21。若本地 Android Studio 不支持该版本，请先升级 Android Studio 或按其提示调整插件版本。

## 设备验证流程
1. 先打开雅迪智行 App，确认车辆已正常连接；然后完全退出或断开官方 App，避免它占用 BLE 连接。
2. 车辆上电，手机靠近仪表，在本 App 点击“扫描附近 BLE 设备”。
3. 记录设备名称、地址（注意属于设备标识，分享日志前可打码）、RSSI。
4. 逐一对可疑设备点击连接，记录 GATT 服务/特征 UUID 与属性。
5. 不要因为名称含 YADEA 或出现 WRITE 属性就发送数据。
6. 对照官方 App 的实际操作和合法可获取的文档/厂商支持信息，确认协议、图片规格、授权/认证及写入语义后，再单独实现上传模块。

## Android 权限
Android 12+ 使用 BLUETOOTH_SCAN / BLUETOOTH_CONNECT 运行时权限；Android 11 及更早版本需要定位权限才能扫描 BLE。代码使用 `neverForLocation`，因此部分被系统判定为位置相关的 BLE 广播可能不会显示。

## 已知限制
- 此执行环境未验证 Android SDK/Gradle 构建，因此此 ZIP 是可导入的源码原型，不宣称已编译或已在目标车上验证。
- 系统图片选择器使用 GetContent，保存为源格式字节副本并以 `.jpg` 命名不适合所有源格式；若选择 PNG/WebP，扩展名可能不准确。后续应改为解码并重新编码为 JPEG/PNG，并加入裁剪与目标尺寸转换。
- 当前 UI 为基础原生布局，尚未进行品牌级视觉打磨。


## GitHub Actions 自动构建（已配置）
工作流文件：`.github/workflows/build-apk.yml`。

上传解压后的项目到 GitHub 仓库根目录后：
- push 到 `main` 或 `master` 且修改了项目文件时会自动构建；
- 也可以在仓库的 Actions 页手动运行 `Build Android APK`；
- 成功后进入本次 workflow run 页面，在 Artifacts 区域下载 `YadeaWallpaperStudio-debug-apk`；
- 解压 artifact 得到 `app-debug.apk`，安装时可能需要允许浏览器/文件管理器安装未知应用。

此工作流生成 debug APK，适合个人测试，不是发布签名版。
