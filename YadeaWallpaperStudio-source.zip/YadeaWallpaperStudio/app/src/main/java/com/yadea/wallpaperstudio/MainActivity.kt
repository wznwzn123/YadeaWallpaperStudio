package com.yadea.wallpaperstudio

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var selectedUri: Uri? = null
    private var gatt: BluetoothGatt? = null
    private val found = linkedMapOf<String, BluetoothDevice>()
    private val logLines = mutableListOf<String>()

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    preview.setImageBitmap(bmp)
                    log("已选择图片：${bmp.width} × ${bmp.height}")
                    status.text = "图片已载入。当前版本仅提供本地工作台，不会上传到仪表。"
                }
            } catch (e: Exception) {
                log("图片读取失败：${e.message}")
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) startScan()
        else status.text = "未获得所需蓝牙权限。请在系统设置中允许“附近设备”。"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        buildUi()
        log("版本 0.1.0-diagnostic；车型配置：G5Ⅱ Pro-M 悦享版双碟 EC-A；仪表固件记录：0.43")
        log("安全模式：扫描与 GATT 服务只读枚举；未实现壁纸写入协议。")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(20))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)

        content.addView(TextView(this).apply {
            text = "YADEA\nWallpaper Studio"
            textSize = 28f
            setTextColor(0xFF14213D.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "仪表壁纸工作台 · 蓝牙协议诊断"
            textSize = 14f
            setTextColor(0xFF596579.toInt())
            setPadding(0, dp(6), 0, dp(16))
        })

        section(content, "01  壁纸工作台")
        preview = ImageView(this).apply {
            minimumHeight = dp(180)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFFE2E7EF.toInt())
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "壁纸预览"
        }
        content.addView(preview, LinearLayout.LayoutParams(-1, dp(210)))
        button(content, "从相册选择图片") { pickImage.launch("image/*") }
        button(content, "保存到应用本地壁纸库") { saveImage() }
        content.addView(TextView(this).apply {
            text = "提示：当前版本保存的是手机本地图片。分辨率、编码格式和仪表上传协议尚未确认。"
            textSize = 12f
            setTextColor(0xFF596579.toInt())
            setPadding(0, dp(4), 0, dp(12))
        })

        section(content, "02  蓝牙诊断（只读）")
        status = TextView(this).apply {
            text = "准备就绪。请先让车辆处于可连接状态，并尽量靠近仪表。"
            textSize = 14f
            setTextColor(0xFF14213D.toInt())
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(status)
        button(content, "扫描附近 BLE 设备") { requestScanPermissions() }
        button(content, "停止扫描") {
            try { bluetoothAdapter.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
            status.text = "已请求停止扫描。"
        }
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(deviceList)

        section(content, "03  诊断日志")
        button(content, "复制日志") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Yadea BLE diagnostic", logLines.joinToString("\n")))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        }
        button(content, "清空日志") {
            logLines.clear()
            refreshLog()
        }
        val logView = TextView(this).apply {
            tag = "logView"
            textSize = 12f
            setTextColor(0xFF283447.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(0xFFE8EDF4.toInt())
        }
        content.addView(logView)
        refreshLog()
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFF14213D.toInt())
            setPadding(0, dp(18), 0, dp(8))
        })
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(5) })
    }

    private fun requestScanPermissions() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            status.text = "此手机不支持 BLE。"
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            startActivity(Intent(android.bluetooth.BluetoothAdapter.ACTION_REQUEST_ENABLE))
            status.text = "请打开蓝牙后再次点击扫描。"
            return
        }
        val needed = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray()) else startScan()
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val key = device.address ?: return
            if (!found.containsKey(key)) {
                found[key] = device
                runOnUiThread {
                    val label = try { device.name ?: "(无广播名称)" } catch (_: SecurityException) { "(名称权限不足)" }
                    log("发现设备：$label · $key · RSSI ${result.rssi} dBm")
                    addDeviceRow(device, label, result.rssi)
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread {
                status.text = "扫描失败，错误码：$errorCode"
                log("BLE scan failed: $errorCode")
            }
        }
    }

    private fun startScan() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "缺少蓝牙扫描权限。"
            return
        }
        found.clear()
        deviceList.removeAllViews()
        status.text = "正在扫描 12 秒。设备名可能为空；请勿仅凭名称认定目标仪表。"
        try {
            bluetoothAdapter.bluetoothLeScanner?.startScan(scanCallback)
            root.postDelayed({
                try { bluetoothAdapter.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
                status.text = "扫描结束：发现 ${found.size} 个 BLE 设备。点击设备查看 GATT 服务。"
            }, 12000)
        } catch (e: SecurityException) {
            status.text = "蓝牙权限不足：${e.message}"
        } catch (e: Exception) {
            status.text = "启动扫描失败：${e.message}"
        }
    }

    private fun addDeviceRow(device: BluetoothDevice, label: String, rssi: Int) {
        val b = Button(this).apply {
            text = "$label\n${device.address}  ·  $rssi dBm"
            isAllCaps = false
            textSize = 12f
            setOnClickListener { connectReadOnly(device) }
        }
        deviceList.addView(b, LinearLayout.LayoutParams(-1, dp(60)))
    }

    @Suppress("DEPRECATION")
    private fun connectReadOnly(device: BluetoothDevice) {
        try {
            status.text = "正在连接并枚举 GATT 服务……"
            log("尝试连接：${device.address}")
            gatt?.close()
            gatt = if (Build.VERSION.SDK_INT >= 23) {
                device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                device.connectGatt(this, false, gattCallback)
            }
        } catch (e: Exception) {
            status.text = "连接失败：${e.message}"
            log("连接异常：${e.message}")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                log("GATT 已连接，状态码 $statusCode；开始发现服务")
                g.discoverServices()
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                log("GATT 已断开，状态码 $statusCode")
                runOnUiThread { status.text = "设备已断开。" }
                g.close()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            runOnUiThread {
                if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                    status.text = "服务发现失败，状态码 $statusCode"
                    log("服务发现失败：$statusCode")
                    return@runOnUiThread
                }
                val sb = StringBuilder("已读取 ${g.services.size} 个服务。当前只读取 UUID/属性，不写入数据。\n")
                g.services.forEach { service ->
                    sb.append("\n服务：${service.uuid} (${service.typeLabel()})\n")
                    log("SERVICE ${service.uuid} type=${service.type}")
                    service.characteristics.forEach { ch ->
                        val props = props(ch)
                        sb.append("  特征：${ch.uuid} | $props\n")
                        log("  CHAR ${ch.uuid} props=$props")
                        ch.descriptors.forEach { desc -> log("    DESC ${desc.uuid}") }
                    }
                }
                status.text = sb.toString()
            }
        }
    }

    private fun props(c: BluetoothGattCharacteristic): String {
        val p = c.properties
        val list = mutableListOf<String>()
        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) list += "READ"
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) list += "WRITE"
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) list += "WRITE_NO_RESPONSE"
        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) list += "NOTIFY"
        if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) list += "INDICATE"
        return list.joinToString(",").ifEmpty { "无常见属性" }
    }

    private fun BluetoothGattService.typeLabel() =
        if (type == BluetoothGattService.SERVICE_TYPE_PRIMARY) "PRIMARY" else "SECONDARY"

    private fun saveImage() {
        val uri = selectedUri
        if (uri == null) {
            Toast.makeText(this, "请先选择图片", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val dir = File(filesDir, "wallpapers").apply { mkdirs() }
            val name = "wallpaper_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
            val target = File(dir, name)
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw IllegalStateException("无法打开图片")
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            log("图片已保存到应用私有目录：$name")
            Toast.makeText(this, "已保存到应用本地壁纸库", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            log("保存图片失败：${e.message}")
            Toast.makeText(this, "保存失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logLines.add("[$time] $message")
        if (logLines.size > 300) logLines.removeAt(0)
        runOnUiThread { refreshLog() }
    }

    private fun refreshLog() {
        val view = root.findViewWithTag<TextView>("logView") ?: return
        view.text = logLines.joinToString("\n").ifEmpty { "暂无日志" }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { bluetoothAdapter.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
        gatt?.close()
        gatt = null
        super.onDestroy()
    }
}
